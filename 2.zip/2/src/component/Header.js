import React from "react";

function Header()
{
    return(
        <>
            <h1>Registration form</h1>
        </>
 
    )
}

export default Header;