import React, { useReducer, useState } from "react";
import Success from "./Success";
import ReactDOM from 'react-dom/client';
import Header from "./Header";
function Form()
{
    let [usn,setUsn] = useState("");
    let [name,setName] = useState("");
    let [department,setDepartment] = useState("");
    let [fees,setFees] = useState("");
    let [sem,setSem] = useState("");
    let [number,setNumber] = useState(""); 

    let handleSubmit = (e) =>
    {
        e.preventDefault();

        let root = ReactDOM.createRoot(document.getElementById("root"));
        root.render(
            <React.StrictMode>
                    <Success usn={usn} name={name} department={department} fees={fees} sem={sem} number={number}></Success>
            </React.StrictMode>
        );
    }

    
    return(
        <>
        <br/>
        <div className="box">
            <Header></Header><hr></hr>
            <form onSubmit={handleSubmit}>
            <label>USN:</label><br/>
            <input type="text" className="ip" required pattern="[0-9]{1}[a-zA-Z]{2}[0-9]{2}[a-zA-Z]{2}[0-9]{3}"
            onChange={(e)=>setUsn(e.target.value)}/><br/><br/>

            <label>Name:</label><br/>
            <input type="text" required className="ip"
            onChange={(e)=>setName(e.target.value)}/><br/><br/>

            <label>Department:</label><br/>
            <input type="text" required className="ip"
            onChange={(e)=>setDepartment(e.target.value)}/><br/><br/>

            <label>Fees:</label><br/>
            <input type="number" min="0" required className="ip"
            onChange={(e)=>setFees(e.target.value)}/><br/><br/>

            <label>Sem:</label><br/>
            <input type="number" min="0" max="6" required className="ip"
            onChange={(e)=>setSem(e.target.value)}/><br/><br/>

            <label>Mobile number:</label><br/>
            <input type="number" pattern="[0-9]{10}" required className="ip"
            onChange={(e)=>setNumber(e.target.value)}/><br/><br/>

        <button type="submit" className="sub">SUBMIT</button>
        </form>

        </div>
        </>
        
        
    )
}

export default Form;