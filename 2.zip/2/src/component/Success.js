import React from "react"
function Success({usn,name,department,fees,sem,number})
{
    return(
        <div className="box">
            <table>
                <tr>
                    <td>USN</td>
                    <td>{usn}</td>
                </tr>
                <tr>
                    <td>Name</td>
                    <td>{name}</td>
                </tr>
                <tr>
                    <td>department</td>
                    <td>{department}</td>
                </tr>
                <tr>
                    <td>fees</td>
                    <td>{fees}</td>
                </tr>
                <tr>
                    <td>sem</td>
                    <td>{sem}</td>
                </tr>
                <tr>
                    <td>number</td>
                    <td>{number}</td>
                </tr>
            </table>
        </div>
    )
}
export default Success;