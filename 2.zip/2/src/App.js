import './App.css';
import Form from './component/Form';

function App() {
  return (
    <>
      <div>
      <Form></Form>
      </div>
    </>
  );
}

export default App;
